<?php
require_once __DIR__ . '/database.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function require_login() { if (empty($_SESSION['user_id'])) { header('Location: login.php'); exit; } }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
 $name=trim($_POST['fullname'] ?? ''); $email=trim($_POST['email'] ?? ''); $pw=$_POST['password'] ?? '';
 if ($name==='' || $email==='' || strlen($pw)<6) { $_SESSION['flash']='Fill in all fields. Password must be at least 6 characters.'; header('Location: register.php'); exit; }
 $check=$conn->prepare('SELECT id FROM users WHERE email=?'); $check->bind_param('s',$email); $check->execute();
 if ($check->get_result()->num_rows) { $_SESSION['flash']='That email is already registered.'; header('Location: register.php'); exit; }
 $hash=password_hash($pw,PASSWORD_DEFAULT); $stmt=$conn->prepare('INSERT INTO users(fullname,email,password) VALUES(?,?,?)'); $stmt->bind_param('sss',$name,$email,$hash);
 if($stmt->execute()){ $_SESSION['flash']='Registration successful. Please log in.'; header('Location: login.php'); exit; }
 $_SESSION['flash']='Could not register. Please try again.'; header('Location: register.php'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
 $email=trim($_POST['email'] ?? ''); $pw=$_POST['password'] ?? '';
 $stmt=$conn->prepare('SELECT id,fullname,password FROM users WHERE email=?'); $stmt->bind_param('s',$email); $stmt->execute(); $user=$stmt->get_result()->fetch_assoc();
 if($user && password_verify($pw,$user['password'])){ session_regenerate_id(true); $_SESSION['user_id']=$user['id']; $_SESSION['fullname']=$user['fullname']; header('Location: dashboard.php'); exit; }
 $_SESSION['flash']='Incorrect email or password.'; header('Location: login.php'); exit;
}
