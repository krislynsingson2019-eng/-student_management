<?php session_start(); $page_title='Welcome | HOLA'; require 'header.php'; ?>
<div class="welcome card p-4 p-md-5 text-center"><h1 class="display-5 fw-bold">HOLA Product Management</h1><p class="lead text-secondary">A simple way to manage your products and inventory.</p><div class="d-flex justify-content-center flex-wrap gap-2 mt-3"><a class="btn btn-primary btn-lg" href="login.php">Log In</a><a class="btn btn-outline-primary btn-lg" href="register.php">Create Account</a></div></div>
<?php require 'footer.php'; ?>
