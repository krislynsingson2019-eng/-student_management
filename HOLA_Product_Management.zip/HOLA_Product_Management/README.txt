HOLA PRODUCT MANAGEMENT SYSTEM

Files:
index.php       Welcome page
login.php      Login form
register.php   Registration form
auth.php       Handles registration and login
 dashboard.php  Inventory overview (requires login)
products.php   Add, view, edit, and delete products
logout.php    Ends login session
 database.php  Creates hola_product_db and tables on first connection
header.php/footer.php shared layout
assets/style.css styling

HOW TO RUN IN TERMUX:
1. Start MariaDB in a Termux session with: mariadbd-safe
2. In another session, go to this project folder.
3. Start PHP server with: php -S 127.0.0.1:8080
4. Open Chrome and visit: http://127.0.0.1:8080

Database and tables are created automatically by database.php when PHP connects.
